<?php declare(strict_types=1);

namespace Lunar\Payment\lib\Exception;

/**
 * Class ApiConnection
 *
 *
 */
class ApiConnection extends ApiException
{

}
