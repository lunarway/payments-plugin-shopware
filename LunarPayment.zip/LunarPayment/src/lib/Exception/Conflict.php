<?php declare(strict_types=1);

namespace Lunar\Payment\lib\Exception;

/**
 * Class Conflict
 *
 *
 */
class Conflict extends ApiException
{

}
