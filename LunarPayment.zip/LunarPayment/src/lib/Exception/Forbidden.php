<?php declare(strict_types=1);

namespace Lunar\Payment\lib\Exception;

/**
 * Class Forbidden
 *
 *
 */
class Forbidden extends ApiException
{

}
