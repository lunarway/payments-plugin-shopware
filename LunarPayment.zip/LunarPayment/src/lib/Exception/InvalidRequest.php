<?php declare(strict_types=1);

namespace Lunar\Payment\lib\Exception;

/**
 * Class InvalidRequest
 *
 *
 */
class InvalidRequest extends ApiException
{

}
